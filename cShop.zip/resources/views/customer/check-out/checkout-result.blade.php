@extends('customer.layout.master')

@section('title','Check Out Result')

@section('content')
    <div class="alert alert-success text-center" role="alert">
        Order placed successfully!
    </div>
@endsection
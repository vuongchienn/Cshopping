@extends('admin.layout.master')

@section('content')

                <!-- Main -->
                <div class="app-main__inner">

                    <div class="app-page-title">
                        <div class="page-title-wrapper">
                            <div class="page-title-heading">
                                <div class="page-title-icon">
                                    <i class="pe-7s-ticket icon-gradient bg-mean-fruit"></i>
                                </div>
                                <div>
                                    Product deatil
                                    <div class="page-title-subheading">
                                        View, create, update, delete and manage.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="main-card mb-3 card">
                                <div class="card-body">
                                    <form method="POST" action = "admin/product/{{ $product->id }}/detail/{{ $productDetail->id}}" enctype="multipart/form-data">
                                        @csrf
                                        @method('PUT')
                                        <input type= "hidden" name = "product_id" value = {{ $product->id }}>
                                        <div class="position-relative row form-group">
                                            <label class="col-md-3 text-md-right col-form-label">Product Name</label>
                                            <div class="col-md-9 col-xl-8">
                                                <input disabled placeholder="Product Name" type="text"
                                                    class="form-control" value="{{ $product->name }}">
                                                    
                                            </div>
                                        </div>

                                        <div class="position-relative row form-group">
                                            <label for="color" class="col-md-3 text-md-right col-form-label">Color</label>
                                            <div class="col-md-9 col-xl-8">
                                                <input  name="color" id="color" placeholder="Color" type="text"
                                                    class="form-control" value="{{ $productDetail->color }}">
                                                    @if ($errors->has('color'))
                                                    <div class="text-danger">
                                                {{ $errors->first('color') }}
                                                @endif
                                            </div>
                                        </div>

                                        <div class="position-relative row form-group">
                                            <label for="size" class="col-md-3 text-md-right col-form-label">Size</label>
                                            <div class="col-md-9 col-xl-8">
                                                <input  name="size" id="size" placeholder="Size" type="text"
                                                    class="form-control" value="{{ $productDetail->size }}">
                                                    @if ($errors->has('size'))
                                                    <div class="text-danger">
                                                {{ $errors->first('size') }}
                                                @endif
                                            </div>
                                        </div>

                                        <div class="position-relative row form-group">
                                            <label for="quantity" class="col-md-3 text-md-right col-form-label">Quantity</label>
                                            <div class="col-md-9 col-xl-8">
                                                <input  name="quantity" id="quantity" placeholder="quantity" type="text"
                                                    class="form-control" value="{{ $productDetail->quantity }}">
                                                    @if ($errors->has('quantity'))
                                                    <div class="text-danger">
                                                {{ $errors->first('quantity') }}
                                                @endif
                                            </div>
                                        </div>
                                        <input class ="hidden" name = "oldQuantity" value = "{{ $productDetail->quantity }}">
                                        <div class="position-relative row form-group mb-1">
                                            <div class="col-md-9 col-xl-8 offset-md-2">
                                                <a href="admin/product/{{ $product->id }}/detail" class="border-0 btn btn-outline-danger mr-1">
                                                    <span class="btn-icon-wrapper pr-1 opacity-8">
                                                        <i class="fa fa-times fa-w-20"></i>
                                                    </span>
                                                    <span>Cancel</span>
                                                </a>

                                                <button type="submit"
                                                    class="btn-shadow btn-hover-shine btn btn-primary">
                                                    <span class="btn-icon-wrapper pr-2 opacity-8">
                                                        <i class="fa fa-download fa-w-20"></i>
                                                    </span>
                                                    <span>Save</span>
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Main -->
@endsection
@section('sidebar')
<div class="scrollbar-sidebar">
    <div class="app-sidebar__inner">
        <ul class="vertical-nav-menu">
            <li class="app-sidebar__heading">Menu</li>

            <li class="mm-active">
                <a href="#">
                    <i class="metismenu-icon pe-7s-plugin"></i>Applications
                    <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                </a>
                <ul>
                    <li>
                        <a href="{{ Route('users.index') }}" >
                            <i class="metismenu-icon"></i>User
                        </a>
                    </li>
                    <li>
                        <a href="{{ Route('orders.index') }}" >
                            <i class="metismenu-icon"></i>Order
                        </a>
                    </li>
                    <li>
                        <a href="{{ Route('product.index') }}" class="mm-active">
                            <i class="metismenu-icon"></i>Product
                        </a>
                    </li>
                    <li>
                        <a href="{{ Route('categories.index') }}" >
                            <i class="metismenu-icon"></i>Category
                        </a>
                    </li>
                    <li>
                        <a href="{{ Route('brands.index')  }}" >
                            <i class="metismenu-icon"></i>Brand
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</div>
@endsection
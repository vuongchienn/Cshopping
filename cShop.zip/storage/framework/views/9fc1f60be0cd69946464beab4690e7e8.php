<?php $__env->startSection('title','Shopping Cart'); ?>

<?php $__env->startSection('content'); ?>
       
        <div class ="register-login-section spad">
            <div class=  "container">
                <div class= "row">
                    <div class ="col-lg-6 offset-lg-3">
                        <div class ="register-form">
                            <h2>Up avatar</h2>
                            <form action = "<?php echo e(Route('avatar.store')); ?>" method = "POST" enctype="multipart/form-data">
                               
                                <?php echo csrf_field(); ?>
                                <input type="file" name="image" accept="image/*" required>
                                <br>
                                <button type="submit" class="site-btn register-btn">Upload</button>
                                
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyProject\Cshop\cShop\resources\views/customer/up-avatar.blade.php ENDPATH**/ ?>
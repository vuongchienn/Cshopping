<?php $__env->startSection('title','Shopping Cart'); ?>

<?php $__env->startSection('content'); ?>


    <!-- Breadcrumb Logo Section Begin -->
    <div class ="breacrumb-section">
        <div class = 'container'>
            <div class="row">
                    <div class="col-lg-12">
                        <div class = "breadcrumb-text">
                            <a href = "<?php echo e(Route('home')); ?>"><i class = "fa fa-home"></i>Home</a>
                            <a href = "<?php echo e(Route('products.index')); ?>">Shop</a>
                            <span>Shopping Cart</span>
                        </div>
                    </div>
            </div>
        </div>
    </div>

    <!-- Shopping Cart Section -->
    <div class = "shopping-cart spad">
        <div class = "container">
            <div class= "row">
                <div class= "col-lg-12">
                    <div class=  "cart-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th class = "p-name">Product Name</th>
                                    <th>Color</th>
                                    <th>Size</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $totalPrice = 0
                                ?>
                                <?php $__currentLoopData = $productInCarts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productInCart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                        $totalPrice += $productInCart->pivot->quantity * $productInCart->product->price;
                                                        ?>
                                    <tr>
                                        <td class ="cart-pic first-row"><img src= "<?php echo e(asset('storage/' . $productInCart->product->productImages->first()->path)); ?>" alt =""></td>
                                        <td class= "cart-title first-row">
                                            <h5><?php echo e($productInCart->product->name); ?></h5>
                                        </td>
                                        <td class= "cart-title first-row">
                                            <h6><?php echo e($productInCart->color); ?></h5>
                                        </td>
                                        <td class= "cart-title first-row">
                                            <h6><?php echo e($productInCart->size); ?></h5>
                                        </td>
                                        <td class="p-price first-row" data-price="<?php echo e($productInCart->product->price); ?>">$<?php echo e($productInCart->product->price); ?></td>
                                        <td class="qua-col first-row">
                                            <div class="quantity">
                                                <div >
                                                    <input type="text" class="styled-input"  value="<?php echo e($productInCart->pivot->quantity); ?>" readonly>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="total-price first-row">$<?php echo e(($productInCart->pivot->quantity * $productInCart->product->price)); ?></td>

                                        <form action = <?php echo e(Route('cart.destroy',$productInCart->product->id)); ?> method = "POST">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <input type= "hidden" value = "<?php echo e($productInCart->color); ?>" name = "color">
                                            <input type= "hidden" value = "<?php echo e($productInCart->size); ?>" name = "size">
                                            <td class= "close-td first-row"><button style = "border:none;background:white;" type = "submit"><i class= "ti-close"></i></button></td>
                                        </form>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>
                    </div>

                    <div class = "row">
                        <div class = "col-lg-4">
                            <div class= "cart-buttons">
                                <a href = "<?php echo e(Route('products.index')); ?>" class= "primary-btn continue-shop">Continue shopping</a>
                            
                            </div>
                            <div class = "discount-coupon">
                                <h6>Discount Codes</h6>
                                <form action = "#" class ="coupon-form">
                                    <input type = "text" placeholder= "Enter your codes">
                                    <button type= "submit" class= "site-btn coupon-btn">Apply</button>
                                </form>
                            </div>
                        </div>
                        <div class= "col-lg-4 offset-lg-4">
                            <div class = "proceed-checkout">
                                <ul>
                                    <li class = "subtotal">Subtotal<span>$<?php echo e($totalPrice); ?></span></li>
                                    <li class = "cart-total">Total<span>$<?php echo e($totalPrice); ?></span></li>
                                </ul>
                                <a href=  "<?php echo e(Route('check-out.index')); ?>" class = "proceed-btn">PROCEED TO CHECK OUT</a>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyProject\Cshop\cShop\resources\views/customer/cart/index.blade.php ENDPATH**/ ?>
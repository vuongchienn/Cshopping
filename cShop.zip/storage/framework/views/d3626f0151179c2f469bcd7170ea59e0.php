<?php $__env->startSection('content'); ?>
                <!-- Main -->
                <div class="app-main__inner">
                    <div class="app-page-title">
                        <div class="page-title-wrapper">
                            <div class="page-title-heading">
                                <div class="page-title-icon">
                                    <i class="pe-7s-ticket icon-gradient bg-mean-fruit"></i>
                                </div>
                                <div>
                                    Order
                                    <div class="page-title-subheading">
                                        View, create, update, delete and manage.
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="main-card mb-3 card">

                                <div class="card-header">

                                    <form action = <?php echo e(Route('searchOrder')); ?> method = "POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="input-group">
                                            <input type="search" name="search" id="search"
                                                placeholder="Search everything" class="form-control">
                                            <span class="input-group-append">
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="fa fa-search"></i>&nbsp;
                                                    Search
                                                </button>
                                            </span>
                                        </div>
                                    </form>

                                   
                                </div>

                                <div class="table-responsive">
                                    <table class="align-middle mb-0 table table-borderless table-striped table-hover">
                                        <thead>

                                            <tr>
                                                <th class="text-center">ID</th>
                                                <th>Customer / Products</th>
                                                <th class="text-center">Address</th>
                                                <th class="text-center">Amount</th>
                                                <th class="text-center">Status</th>
                                                <th class="text-center">Actions</th>
                                            </tr>

                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center text-muted">#<?php echo e($order->id); ?></td>
                                                <td>
                                                    <div class="widget-content p-0">
                                                        <div class="widget-content-wrapper">
                                                            <div class="widget-content-left mr-3">
                                                                <div class="widget-content-left">
                                                                    
                                                                    <img style="height: 60px;"
                                                                        data-toggle="tooltip" title="Image"
                                                                        data-placement="bottom"
                                                                        src="<?php echo e(asset('storage/' . $order->orderDetails->first()->productDetail->product->productImages->first()->path)); ?>" alt="">
                                                                </div>
                                                            </div>
                                                            <div class="widget-content-left flex2">
                                                                <div class="widget-heading"><?php echo e($order->first_name. ' '. $order->last_name); ?></div>
                                                                <div class="widget-subheading opacity-7">
                                                                    <?php echo e($order->orderDetails->first()->productDetail->product->name); ?>

                                                                    <?php if(count($order->orderDetails)>1): ?>
                                                                        (and <?php echo e(count($order->orderDetails)-1); ?> other products)
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="text-center">
                                                    <?php echo e($order->steet_address); ?> - <?php echo e($order->city); ?>

                                                </td>
                                                <td class="text-center">$<?php echo e(array_sum(array_column($order->orderDetails->toArray(),'total'))); ?></td>
                                                <td class="text-center">
                                                    <div class="badge badge-dark">
                                                        <?php if($order->status ==1): ?>
                                                            Preparing
                                                        <?php elseif($order->status ==2): ?>
                                                            Shipping
                                                        <?php else: ?>
                                                            Finish
                                                        <?php endif; ?>
                                                        
                                                    </div>
                                                </td>
                                                <td class="text-center">
                                                    <a href="<?php echo e(Route('orders.show',$order->id)); ?>"
                                                        class="btn btn-hover-shine btn-outline-primary border-0 btn-sm">
                                                        Details
                                                    </a>
                                                </td>
                                            </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>

                                <div class="d-block card-footer">
                                    <?php echo e($orders->links('pagination::bootstrap-5')); ?>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Main -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>
<div class="scrollbar-sidebar">
    <div class="app-sidebar__inner">
        <ul class="vertical-nav-menu">
            <li class="app-sidebar__heading">Menu</li>

            <li class="mm-active">
                <a href="#">
                    <i class="metismenu-icon pe-7s-plugin"></i>Applications
                    <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                </a>
                <ul>
                    <li>
                        <a href="<?php echo e(Route('users.index')); ?>" >
                            <i class="metismenu-icon"></i>User
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(Route('orders.index')); ?>" class="mm-active">
                            <i class="metismenu-icon"></i>Order
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(Route('product.index')); ?>">
                            <i class="metismenu-icon"></i>Product
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(Route('categories.index')); ?>" >
                            <i class="metismenu-icon"></i>Category
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(Route('brands.index')); ?>" >
                            <i class="metismenu-icon"></i>Brand
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyProject\Cshop\cShop\resources\views/admin/order/index.blade.php ENDPATH**/ ?>
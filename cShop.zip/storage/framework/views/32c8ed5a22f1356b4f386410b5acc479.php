<?php $__env->startSection('title','Product'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Breadcrumb Logo Section Begin -->
    <div class ="breacrumb-section">
        <div class = 'container'>
            <div class="row">
                    <div class="col-lg-12">
                        <div class = "breadcrumb-text">
                            <a href = "<?php echo e(Route('home')); ?>"><i class = "fa fa-home"></i>Home</a>
                            <a href = "<?php echo e(Route('products.index')); ?>">Shop</a>
                            <span>Details</span>
                        </div>
                    </div>
            </div>
        </div>
    </div>



    
    <section class= "product-shop spad page-details">
        <div class ="container">
            <div class = "row">
                <div class= "col-lg-12">
                    <div class= "row">
                        <div class = "col-lg-6">
                            <div class = "product-pic-zoom">
                                <img src=  "<?php echo e($product->productImages->isNotEmpty() ? asset('storage/' . $product->productImages->first()->path) : asset('./customer/img/products/man-1.jpg')); ?>" alt="<?php echo e($product->name); ?>" class = "product-big-img" alt = "">
                                <div class = "zoom-icon">
                                    <i class = "fa fa-search-plus"></i>
                                </div>
                            </div>
                            <div class = "product-thumbs">
                                <div class ="product-thumbs-track ps-slider owl-carousel">
                                    <?php $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class ="pt active" data-imgbigurl ="<?php echo e(asset('storage/' . $image->path)); ?>">
                                            <img src= "<?php echo e($product->productImages->isNotEmpty() ? asset('storage/' . $image->path) : asset('./customer/img/products/man-1.jpg')); ?>" alt="<?php echo e($product->name); ?>" alt ="">
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>

                        <div class = "col-lg-6">
                            <div class= "product-details">
                                <div class = "pd-title">
                                    <span><?php echo e($product->tag); ?></span>
                                    <h3><?php echo e($product->name); ?></h3>
                                    <a href=  "#" class ="heart-icon"><i class = "icon_heart_alt"></i></a>
                                </div>

                                <div class = "pd-rating">
                                    <?php for($i=1;$i<=5;$i++): ?>
                                        <?php if($i<=$product->avgRating): ?>
                                            <i class = "fa fa-star"></i>
                                        <?php elseif($i-$product->avgRating<1): ?>
                                            <i class = "fa fa-star-half"></i>
                                        <?php else: ?>
                                            <i class = "fa fa-star-o"></i>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                    <span><?php echo e($product->avgRating); ?></span>
                                    <span>(<?php echo e(count($product->productComments)); ?>)</span>
                                </div>

                                <div class = "pd-desc">
                                    <p><?php echo e($product->content); ?></p>
                                    <h4>$<?php echo e($product->discount); ?><span>$<?php echo e($product->price); ?></span></h4>
                                </div>
                                <form action = "<?php echo e(Route('cart.store')); ?>" method = "POST"> 
                                    <?php echo csrf_field(); ?>
                                <div class= "pd-color">
                                    <h6>Color</h6>
                                    <div class="pd-color-choose">
                                        <?php $__currentLoopData = collect($product->productDetails)->pluck('color')->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class= "cc-item">
                                            <input type= "radio" id ="cc-<?php echo e(strtolower($color)); ?>" value = <?php echo e($color); ?> name = "color"> 
                                            <label for = "cc-<?php echo e(strtolower($color)); ?>" class = "cc-<?php echo e(strtolower($color)); ?>"></label>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($errors->has('color')): ?>
                                        <div class="text-danger">
                                            <?php echo e($errors->first('color')); ?>

                                        </div>
                                    <?php endif; ?>
                                    </div>
                                </div>

                                <div class="pd-size-choose">
                                    <?php $__currentLoopData = collect($product->productDetails)->pluck('size')->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class = "sc-item">
                                        <input type = "radio" id = "sm-<?php echo e($size); ?>" value = "<?php echo e($size); ?>" name = "size">
                                        <label for = "sm-<?php echo e($size); ?>"><?php echo e($size); ?></label>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($errors->has('size')): ?>
                                    <div class="text-danger">
                                        <?php echo e($errors->first('size')); ?>

                                    </div>
                                <?php endif; ?>
                                </div>

                                <div class= "quantity">
                                      
                                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                            <div class= "quantity">
                                                <div class="pro-qty">
                                                    <input type= "text" name = 'quantity' value = "1">
                                                </div>
                                                <button type ="submit" class= "primary-btn pd-cart"><a>Add To Cart</a></button>
                                            </div>
                                </div>
                            </form>
                                <ul class= "pd-tags">
                                    <li>    
                                        <span>CATEGORIES</span>: <?php echo e($product->category->name); ?>

                                    </li>
                                    <li>
                                        <span>TAGS</span>: <?php echo e($product->tag); ?>

                                    </li>
                                    <li>
                                        <span>BRAND</span>: <?php echo e($product->brand->name); ?>

                                    </li>
                                </ul>

                                <div class="pd-share">
                                    <div class=  "pd-social">
                                        <a href="#"><i class=  "ti-facebook"></i></a>
                                        <a href="#"><i class ="ti-twitter-alt"></i></a>
                                        <a href="#"><i class= "ti-linkedin"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class= "product-tab">
                        <div class= "tab-item">
                            <ul class = "nav" role ="tablist">
                                <li><a class ="active" href="#tab-1" data-toggle="tab" role = "tab">DESCRIPTION</a></li>
                                <li><a href="#tab-2" data-toggle="tab" role = "tab">SPECIFICATION</a></li>
                                <li><a href="#tab-3" data-toggle="tab" role = "tab">Customer Reviews (<?php echo e(count($product->productComments)); ?>)</a></li>
                            </ul>
                        </div>  
                        <div class ="tab-item-content">
                            <div class= "tab-content">
                                <div class = "tab-pane fade-in active" id= "tab-1" role = tabpanel>
                                    <div class ="product-content">
                                        <div class = "row">
                                            <div class= "col-lg-7">
                                                <p><?php echo e($product->description); ?></p>
                                            </div>
                                            <div class ="col-lg-5">
                                                <img src = "customer/img/product-single/tab-desc.jpg" alt ="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class ="tab-pane fade" id = "tab-2" role=  "tabpanel">
                                    <div class ="specification-table">
                                        <table>
                                            <tr>
                                                <td class ="p-catagory">Customer Rating</td>
                                                <td>
                                                    
                                                    <div class = "pd-rating">
                                                        <?php for($i=1;$i<=5;$i++): ?>
                                                            <?php if($i<=$product->avgRating): ?>
                                                                <i class= "fa fa-star"></i>
                                                            <?php elseif($i-$product->avgRating<1): ?>
                                                                <i class = "fa fa-star-half"></i>
                                                            <?php else: ?>
                                                                <i class= "fa fa-star-o"></i>
                                                            <?php endif; ?>
                                                        <?php endfor; ?>
                                                        <span>(<?php echo e(count($product->productComments)); ?>)</span>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class = "p-catagory">Price</td>
                                                <td> 
                                                    <div class = "p-price">
                                                        $<?php echo e($product->price); ?>

                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class= "p-catagory">Add To Cart</td>
                                                <td>
                                                    <div class ="cart-add">
                                                        +Add To Cart
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class= "p-catagory">Availability</td>
                                                <td>
                                                    <div class = "p-stock">
                                                        <?php echo e($product->quantity); ?> in stock
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class ="p-catagory">Weight</td>
                                                <td>
                                                    <div class ="p-weight">
                                                        <?php echo e($product->weight); ?>kg
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class ="p-catagory">Size</td>
                                                <td>
                                                    <div class ="p-size">
                                                        <?php $__currentLoopData = collect($product->productDetails)->pluck('size')->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php echo e($size); ?>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class = "p-catagory">Color</td>
                                                <td style="text-align: center; vertical-align: middle;">
                                                    <div class="filter-widget" style="display: flex; justify-content: center;">
                                                        <div class="fw-color-choose" style="display: flex; gap: 10px; justify-content: center;">
                                                            <div class="cs-item" style="display: flex; gap: 10px;">
                                                                <?php $__currentLoopData = collect($product->productDetails)->pluck('color')->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <label class="cs-<?php echo e(strtolower($color)); ?>" style="display: inline-block; width: 18px; height: 18px; border-radius: 50%;"></label>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                                
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                                <div class ="tab-pane fade" id = "tab-3" role = "tabpanel">
                                    <div class= "customer-review-option">
                                        <?php if(count($product->productComments)>1): ?>
                                        <h4><?php echo e(count($product->productComments)); ?> Comments</h4>
                                        <?php else: ?>
                                        <h4><?php echo e(count($product->productComments)); ?> Comment</h4>
                                        <?php endif; ?>
                                        <div class ="comment-option">
                                            <?php $__currentLoopData = $product->productComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pComment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class ="co-item">
                                                <div class = "avatar-pic">
                                                   
                                                        <img src = "<?php echo e(asset(path: 'storage/'. $pComment->user->avatar)); ?>" alt = "">
                                                   
                                                </div>
                                                <div class = "avatar-text">
                                                    <div class= "at-rating">
                                                        <?php for($i=1;$i<=5;$i++): ?>
                                                            <?php if($i<=$pComment->rating): ?>
                                                                <i class ="fa fa-star"></i>
                                                            <?php else: ?>
                                                                <i class ="fa fa-star-o"></i>
                                                            <?php endif; ?>
                                                        <?php endfor; ?>
                                                    </div>
                                                    <h5><?php echo e($pComment->user->name); ?><span><?php echo e($pComment->created_at); ?></span></h5>
                                                    <div class= "at-reply"><?php echo e($pComment->message); ?></div>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                       
                                        <div class ="leave-comment">
                                            <h4>Leave A Commet</h4>
                                            <form action = "<?php echo e(Route("comments.store")); ?>" method = "POST" class = comment-form>
                                                <?php echo csrf_field(); ?>
                                                <div class = "row">
                                                    <div class ="col-lg-12">
                                                        <input type = "hidden" value = "<?php echo e($product->id); ?>" name= "product_id">
                                                        <textarea placeholder = "Messages" name = "message"></textarea>
                                                        <div class = "personal-rating">
                                                                <div class="rate">
                                                                    <input type="radio" id="star5" name="rating" value="5" />
                                                                    <label for="star5" title="text">5 stars</label>
                                                                    <input type="radio" id="star4" name="rating" value="4" />
                                                                    <label for="star4" title="text">4 stars</label>
                                                                    <input type="radio" id="star3" name="rating" value="3" />
                                                                    <label for="star3" title="text">3 stars</label>
                                                                    <input type="radio" id="star2" name="rating" value="2" />
                                                                    <label for="star2" title="text">2 stars</label>
                                                                    <input type="radio" id="star1" name="rating" value="1" />
                                                                    <label for="star1" title="text">1 star</label>
                                                                </div>
                                                        </div>
                                                        <button type=  "submit" class = "site-btn">Send message</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
        

    
    <div class = "related-products spad">
        <div class = "container">
            <div class ="row">
                <div class ="col-lg-12">
                    <div class= "section-title">
                        <h2>Related Products</h2>
                    </div>
                </div>
            </div>
            <div class ="row">
                <?php $__currentLoopData = $product->relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class ="col-lg-3 col-sm-6">
                    <div class = "product-item">
                        <div class= "pi-pic">
                            <img src = "<?php echo e(asset('storage/'.$relatedProduct->productImages->first()->path)); ?>" alt = "">
                            <?php if($relatedProduct->discount != 0): ?>
                                <div class = "sale pp-sale">Sale</div>
                            <?php endif; ?>
                            <div class="icon">
                                <i class = "icon_heart_alt"></i>
                            </div>
                            <ul>
                                <li class=  "w-icon active"><a href = "#"><i class=  "icon_bag_alt"></i></a></li>
                                <li class = "quick-view"><a href = "<?php echo e(Route('products.show',$relatedProduct->id)); ?>">+ Quick view</a></li>
                                <li class = "w-icon"><a href = ""><i class = "fa fa-random"></i></a></li>
                            </ul>
                        </div>
                        <div class=  "pi-text">
                            <div class = "catagory-name"><?php echo e($relatedProduct->category->name); ?></div>
                            <a href=  "#">
                                <h5><?php echo e($relatedProduct->name); ?></h5>
                            </a>
                            <div class=  "product-price">
                                $<?php echo e($relatedProduct->discount); ?>

                                <span>$<?php echo e($relatedProduct->price); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyProject\Cshop\cShop\resources\views/customer/product/show.blade.php ENDPATH**/ ?>
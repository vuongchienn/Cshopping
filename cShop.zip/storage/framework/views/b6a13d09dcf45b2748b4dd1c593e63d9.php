<?php $__env->startSection('title','Check Out'); ?>

<?php $__env->startSection('content'); ?>



    <!-- Breadcrumb Logo Section Begin -->
    <div class ="breacrumb-section">
        <div class = 'container'>
            <div class="row">
                    <div class="col-lg-12">
                        <div class = "breadcrumb-text">
                            <a href = "<?php echo e(Route('home')); ?>"><i class = "fa fa-home"></i>Home</a>
                            <a href = "<?php echo e(Route('products.index')); ?>">Shop</a>
                            <span>Check out</span>
                        </div>
                    </div>
            </div>
        </div>
    </div>


    <!-- Checkout section -->
    <div class = "checkout-section spad">
        <div class= "container">
            <form action = "<?php echo e(Route('order.store')); ?>" method ="POST" class="checkout-form" >
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class ="col-lg-6">
                        <div class= "checkout-content">
                            <a href = "login.html" class="content-btn">Click here to login</a>
                        </div>
                        <h4>Biiling Details</h4>
                        <div class= "row">
                            <div class= "col-lg-6">
                                <label for = "fir">First Name<span>*</span></label>
                                <input type= "text" id ="fir" name='first_name'> 
                                <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class= "col-lg-6">
                                <label for = "last">Last Name<span>*</span></label>
                                <input type= "text" id ="lastlast" name= "last_name"> 
                                <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                
                            <div class= "col-lg-12">
                                <label for = "street">Street Address<span>*</span></label>
                                <input type= "text" id ="street" class="street-first" name = "street_address">
                                <?php $__errorArgs = ['street_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
            
                            <div class= "col-lg-12">
                                <label for = "town">City<span>*</span></label>
                                <input type= "text" id ="town" name = "city"> 
                                <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class= "col-lg-6">
                                <label for = "email">Email Address<span>*</span></label>
                                <input type= "text" id ="email" name = "email"> 
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class= "col-lg-6">
                                <label for = "phone">Phone<span>*</span></label>
                                <input type= "text" id ="phone" name = "phone"> 
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class= 'col-lg-12'>
                                <div class= "create-item">
                                    <label for="acc-create">
                                        Create an account?
                                        <input type=  "checkbox" id = "acc-create">
                                        <span class= "checkmark"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class ="col-lg-6">
                        <div class="checkout-content">
                            <input type = "text" placeholder="Enter Your Coupon Code">
                        </div>
                        <div class ="place-order">
                            <h4>
                                Your Order
                            </h4>
                            <div class = "order-total">
                                <ul class = "order-table">
                                    <li>Product<span>Total</span></li>   
                                    <?php
                                        $totalPrice = 0;
                                    ?>
                                  
                                    <?php $__currentLoopData = $productInCarts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productInCart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $totalPrice += $productInCart->pivot->quantity * $productInCart->product->price;
                                        ?>
                                        <li class = "fw-normal"><?php echo e($productInCart->product->name); ?> x <?php echo e($productInCart->pivot->quantity); ?> <span>$<?php echo e($productInCart->product->price*$productInCart->pivot->quantity); ?></span></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <li class = "fw-normal">Subtotal<span>$<?php echo e($totalPrice); ?></span></li>
                                    <li class = "total-price">Total<span>$<?php echo e($totalPrice); ?></span></li>
                                </ul>
                                <div class="payment-check">
                                    <div class="pc-item">
                                        <label for="pc-check">
                                            Pay later
                                            <input type="radio" id="pc-check" name="payment_method" value="pay_later">
                                            <span class="checkmark"></span>
                                        </label>
                                    </div>
                                    <div class="pc-item">
                                        <label for="pc-paypal">
                                            Pay online
                                            <input type="radio" id="pc-paypal" name="payment_method" value="pay_online">
                                            <span class="checkmark"></span>
                                        </label>
                                    </div>
                                </div>
                                
                                <div class ="order-btn">
                                    <button <?php echo e(is_null($productInCarts->first()) ? 'disabled' : ''); ?>  type="submit" class ="site-btn place-btn">Place Order</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyProject\Cshop\cShop\resources\views/customer/check-out/index.blade.php ENDPATH**/ ?>
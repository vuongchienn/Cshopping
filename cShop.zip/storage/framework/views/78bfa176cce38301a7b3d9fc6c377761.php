<?php $__env->startSection('title','Shop'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Breadcrumb Logo Section Begin -->
    <div class ="breacrumb-section">
        <div class = 'container'>
            <div class="row">
                    <div class="col-lg-12">
                        <div class = "breadcrumb-text">
                            <a href = "#"><i class = "fa fa-home"></i>Home</a>
                            <span>Shop</span>
                        </div>
                    </div>
            </div>
        </div>
    </div>


    <!-- Product Shop section Begin  -->
    <section class = "product-shop spad">
       <div class = "container">
        <div class="row">
            <div class = "col-lg-3 col-md-6 col-sm-8 order-2 order-lg-1 produts-sidebar-filter">
                <div class = "filter-widget">
                    <h4 class = "fw-title">Categories</h4>
                    <ul class = "filter-catagories">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href = "customer/category/<?php echo e($category->name); ?>"><?php echo e($category->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

              
                <div class = "filter-widget">
                    <h4 class = "fw-title">Tags</h4>
                    <div class  = "fw-tags">    
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href = "customer/tag/<?php echo e($tag); ?>"><?php echo e($tag); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <div class = "col-lg-9 order-1 order-lg-2"> 
                <div class = "product-show-option">
                    <div class= "row" >
                        <div class = "col-lg-7 col-md-7">
                            <form action = "<?php echo e(Route('products.index')); ?>">
                                <div class = "select-option">
                                    <select class= "sorting" name = "sort_by" onchange="this.form.submit()">
                                        <option <?php echo e(request('sort_by')=='latest'?'selected':''); ?> value= "newest">Newest</option>
                                        <option <?php echo e(request('sort_by')=='oldest'?'selected':''); ?> value=  "oldest">Oldest</option>
                                        <option <?php echo e(request('sort_by')=='name-ascending'?'selected':''); ?> value=  "name-ascending">Name: A-Z</option>
                                        <option <?php echo e(request('sort_by')=='name-descending'?'selected':''); ?> value=  "name-descending">Name: Z-A</option>
                                        <option <?php echo e(request('sort_by')=='price-ascending'?'selected':''); ?> value=  "price-ascending">Price: Ascending</option>
                                        <option <?php echo e(request('sort_by')=='price-descending'?'selected':''); ?> value=  "price-descending">Price: Decrease</option>
                                    </select>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class = "product-list ">
                    <div class = "row">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <div class = "col-lg-4 col-sm-6">
                            <div class = "product-item">
                                <div class= "pi-pic">
                                    <img src = "<?php echo e($product->productImages->isNotEmpty() ? asset('storage/' . $product->productImages->first()->path) : asset('./customer/img/products/man-1.jpg')); ?>" alt="<?php echo e($product->name); ?>" alt = "">
                                    <div class = "sale pp-sale">Sale</div>
                                    <div class="icon">
                                        <i class = "icon_heart_alt"></i>
                                    </div>
                                    <ul>
                                        <li class=  "w-icon active"><a href = "<?php echo e(Route('cart.store',$product->id)); ?>"><i class=  "icon_bag_alt"></i></a></li>
                                        <li class = "quick-view"><a href = "<?php echo e(Route('products.show',$product->id)); ?>">+ Quick view</a></li>
                                        <li class = "w-icon"><a href = ""><i class = "fa fa-random"></i></a></li>
                                    </ul>
                                </div>
                                <div class=  "pi-text">
                                    <div class = "catagory-name"><?php echo e($product->category->name); ?></div>
                                    <a href=  "#">
                                        <h5><?php echo e($product->name); ?></h5>
                                    </a>
                                    <div class=  "product-price">
                                        $<?php echo e($product->discount); ?>

                                        <span>$<?php echo e($product->price); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                <div>
                    <?php echo e($products->links('pagination::bootstrap-5')); ?>

                </div>
            </div>
        </div> 

       </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyProject\Cshop\cShop\resources\views/customer/shop.blade.php ENDPATH**/ ?>
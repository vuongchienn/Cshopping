<?php $__env->startSection('title','Check Out Result'); ?>

<?php $__env->startSection('content'); ?>
    <div class="alert alert-success text-center" role="alert">
        Order placed successfully!
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyProject\Cshop\cShop\resources\views/customer/checkout-result.blade.php ENDPATH**/ ?>
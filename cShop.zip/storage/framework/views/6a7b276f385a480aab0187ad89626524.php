<?php $__env->startSection('title','Shopping Cart'); ?>

<?php $__env->startSection('content'); ?>


    <!-- Breadcrumb Logo Section Begin -->
    <div class ="breacrumb-section">
        <div class = 'container'>
            <div class="row">
                    <div class="col-lg-12">
                        <div class = "breadcrumb-text">
                            <a href = "#"><i class = "fa fa-home"></i>Home</a>
                            <span>My order</span>
                        </div>
                    </div>
            </div>
        </div>
    </div>


    <div class = "checkout-section spad">
    <div class= "container">
        <form action = "<?php echo e(Route('order.store')); ?>" method ="POST" class="checkout-form" >
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class ="col-lg-6">
                    <div class= "checkout-content">
                        
                        <div class="content-btn">
                            ID:
                            <b>#<?php echo e($order->id); ?></b>
                        </div>
                    </div>
                    <h4>Biiling Details</h4>
                    <div class= "row">
                        <div class= "col-lg-6">
                            <label for = "fir">First Name</label>
                            <input disabled type= "text" id ="fir" name='first_name' value ="<?php echo e($order->first_name); ?>"> 
                        </div>
                        <div class= "col-lg-6">
                            <label for = "last">Last Name</label>
                            <input disabled type= "text" id ="lastlast" name= "last_name" value = "<?php echo e($order->last_name); ?>" > 
                        </div>
            
                        <div class= "col-lg-12">
                            <label for = "street">Street Address</label>
                            <input disabled type= "text" id ="street" class="street-first" name = "street_address" value = "<?php echo e($order->street_address); ?>">
                        </div>
        
                        <div class= "col-lg-12">
                            <label for = "town">City<span>*</span></label>
                            <input disabled type= "text" id ="town" name = "city" value = "<?php echo e($order->city); ?>"> 
                        </div>
                        <div class= "col-lg-6">
                            <label for = "email">Email Address<span>*</span></label>
                            <input disabled type= "text" id ="email" name = "email" value ="<?php echo e($order->email); ?>"> 
                        </div>
                        <div class= "col-lg-6">
                            <label for = "phone">Phone<span>*</span></label>
                            <input disabled type= "text" id ="phone" name = "phone" value = "<?php echo e($order->phone); ?>"> 
                        </div>
                    </div>
                </div>
                <div class ="col-lg-6">
                    <div class="checkout-content">
                        <a href = "#" class = "content-btn">
                            Status:
                            <b>
                                <?php if($order->status == 1): ?>
                                    Preparing the order
                                <?php elseif($order->status == 2): ?>
                                    Shipping the order
                                <?php else: ?>
                                    Order delivered successfully
                                <?php endif; ?>
                            </b>
                        </a>
                    </div>
                    <div class ="place-order">
                        <h4>
                            Your Order
                        </h4>
                        <div class = "order-total">
                            <ul class = "order-table">
                                <li>Product<span>Total</span></li>   
                                <?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class = "fw-normal"><?php echo e($orderDetail->productDetail->product->name); ?> x <?php echo e($orderDetail->quantity); ?> <span>$<?php echo e($orderDetail->total); ?></span></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                              
                                <li class = "total-price">Total<span>$<?php echo e(array_sum(array_column($order->orderDetails->toArray(),'total'))); ?></span></li>
                            </ul>
                            <div class="payment-check">
                                <div class="pc-item">
                                    <label for="pc-check">
                                        Pay later
                                        <input disable type="radio" id="pc-check" name="payment_method" value="pay_later" <?php echo e($order->payment_method == 'pay_later'?'checked':''); ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="pc-item">
                                    <label for="pc-paypal">
                                        Pay online
                                        <input disable type="radio" id="pc-paypal" name="payment_method" value="pay_online" <?php echo e($order->payment_method == 'pay_online'?'checked':''); ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyProject\Cshop\cShop\resources\views/customer/my-order-detail.blade.php ENDPATH**/ ?>